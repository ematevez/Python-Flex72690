

class Sistema:
    pass