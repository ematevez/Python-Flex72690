
class Usuario:
    pass