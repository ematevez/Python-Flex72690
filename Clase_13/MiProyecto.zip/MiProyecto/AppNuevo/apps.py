from django.apps import AppConfig


class AppnuevoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'AppNuevo'
