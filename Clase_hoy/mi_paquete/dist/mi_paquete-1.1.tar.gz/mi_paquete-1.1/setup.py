from setuptools import setup, find_packages

setup(
    name='mi_paquete',
    version='1.1',
    packages=find_packages(),
    install_requires=[
    
    ],
    description='Su tu paquete lala',
    long_description_content_type='text/markdown',
    author='ema',
    author_email='ematevez@ejemplo.com',
    url='https://github.com/tuusuario/mi_paquete',
    classifiers=[
            ],
)

