class Cliente:
   
    def un_gato():
        print ("Soy un gato")
        
    def otro_gato():
        print ("Soy otro gato")