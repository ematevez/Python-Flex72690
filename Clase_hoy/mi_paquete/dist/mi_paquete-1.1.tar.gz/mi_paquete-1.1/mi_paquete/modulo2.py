class Auto:
    
    def un_auto():
        print ("Soy un auto")
        
    def otro_auto():
        print ("Soy otro auto")