from mi_paquete.modulo1 import *
from mi_paquete.modulo2 import *


Cliente.un_gato()
Cliente.otro_gato()

Auto.un_auto()
Auto.otro_auto()